<script setup lang="ts">
import { Link, router } from '@inertiajs/vue3'
import { inject } from 'vue'

defineProps<{ customer: any }>()
const route = inject<(p: string) => string>('route', p => p)

function logout() { router.post(route('/customer/logout')) }

const nav = [
    { name: 'Dashboard',       href: '/customer/dashboard',       icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
    { name: 'Appointments',    href: '/customer/appointments',    icon: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z' },
    { name: 'My Vehicles',     href: '/customer/vehicles',        icon: 'M8.25 18.75a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 01-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 00-3.213-9.193 2.056 2.056 0 00-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 00-10.026 0 1.106 1.106 0 00-.987 1.106v7.635m12-6.677v6.677m0 4.5v-4.5m0 0h-12' },
    { name: 'Invoices',        href: '/customer/invoices',        icon: 'M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z' },
    { name: 'Service History', href: '/customer/service-history', icon: 'M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15a2.25 2.25 0 012.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z' },
    { name: 'Quotes',          href: '/customer/quotes',          icon: 'M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z' },
    { name: 'Support',         href: '/customer/tickets',         icon: 'M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4' },
    { name: 'Profile',         href: '/customer/profile',         icon: 'M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z' },
]

// Mobile bottom nav: limit to 5 key items
const mobileNav = nav.slice(0, 4).concat(nav.find(n => n.name === 'Profile')!)
</script>

<template>
    <div class="min-h-screen bg-gray-50">
        <!-- Top Nav -->
        <header class="bg-white border-b border-gray-200 sticky top-0 z-40">
            <div class="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between">
                <div class="flex items-center gap-2">
                    <div class="w-7 h-7 rounded-lg bg-electric-600 flex items-center justify-center">
                        <span class="text-white font-bold text-xs">DA</span>
                    </div>
                    <span class="font-semibold text-gray-900 text-sm">Doyen Auto Services</span>
                </div>
                <div class="flex items-center gap-3">
                    <span class="text-sm text-gray-600 hidden sm:block">{{ customer.name }}</span>
                    <button @click="logout" class="text-sm text-gray-500 hover:text-red-600">Sign Out</button>
                </div>
            </div>
        </header>

        <div class="max-w-5xl mx-auto px-4 py-6 flex gap-6">
            <!-- Sidebar Nav -->
            <nav class="hidden sm:block w-48 flex-shrink-0 space-y-1">
                <Link v-for="item in nav" :key="item.href" :href="route(item.href)"
                    :class="['flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors', $page.url.startsWith(item.href) ? 'bg-electric-600 text-white' : 'text-gray-600 hover:bg-gray-100']"
                >
                    <svg class="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
                        <path stroke-linecap="round" stroke-linejoin="round" :d="item.icon"/>
                    </svg>
                    {{ item.name }}
                </Link>
            </nav>

            <!-- Content -->
            <main class="flex-1 min-w-0">
                <slot />
            </main>
        </div>

        <!-- Mobile Bottom Nav -->
        <nav class="sm:hidden fixed bottom-0 inset-x-0 bg-white border-t border-gray-200 flex">
            <Link v-for="item in mobileNav" :key="item.href" :href="route(item.href)"
                :class="['flex-1 flex flex-col items-center py-2 text-xs', $page.url.startsWith(item.href) ? 'text-electric-600' : 'text-gray-500']"
            >
                <svg class="w-5 h-5 mb-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" :d="item.icon"/></svg>
                <span>{{ item.name.split(' ')[0] }}</span>
            </Link>
        </nav>
    </div>
</template>
