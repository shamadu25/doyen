<script setup lang="ts">
import { computed, ref } from 'vue'
import { Head, Link, usePage } from '@inertiajs/vue3'
import { inject } from 'vue'

const route = inject<(path: string) => string>('route', (p) => p)

// Props from backend (approved + active + show_on_website services grouped by category)
const props = defineProps<{
    websiteServices?: Record<string, Array<{
        id: number
        name: string
        icon: string | null
        category: string
        description: string | null
        price: number
        duration_minutes: number
        requires_booking: boolean
    }>>
    websiteContent?: {
        hero?: Record<string, string>
        trust?: { items?: string }
        testimonials?: { items?: string }
        process?: { items?: string }
        hours?: Record<string, string>
        seo?: Record<string, string>
        social?: Record<string, string>
    }
}>()

// Live garage contact details from Inertia shared props (set in .env / DB settings)
const garage = computed(() => (usePage().props as any).garageSettings ?? {})
const garagePhone    = computed(() => garage.value.phone    || '+44 7760 926245')
const garageEmail    = computed(() => garage.value.email    || 'info@doyenautos.co.uk')
const garageName     = computed(() => garage.value.garage_name || 'Doyen Auto Services')
const garageAddress  = computed(() => garage.value.address  || '59 Southcroft Road')
const garageCity     = computed(() => garage.value.city     || 'Rutherglen, Glasgow')
const garagePostcode = computed(() => garage.value.postcode || 'G73 1UG')
// Format for tel: link — strip spaces, convert UK leading 0 → +44
const garageTelHref      = computed(() => 'tel:+44' + garagePhone.value.replace(/\s/g, '').replace(/^0/, ''))
const garageMailHref     = computed(() => 'mailto:' + garageEmail.value)
const googleReviewLink   = computed(() => garage.value.google_review_link || 'https://maps.app.goo.gl/dKnuaDHKtwtaHw3u5')

// WhatsApp support chat link — strip non-digits and build wa.me URL
const whatsappSupportHref = computed(() => {
    const raw = garagePhone.value.replace(/\s/g, '').replace(/^\+/, '').replace(/^0/, '44')
    return `https://wa.me/${raw}?text=Hello%2C%20I%20would%20like%20to%20enquire%20about%20your%20services.`
})

// Helper to parse JSON content from websiteContent prop
function parseJsonContent<T>(jsonStr: string | null | undefined, fallback: T[]): T[] {
    if (!jsonStr) return fallback
    try { return JSON.parse(jsonStr) as T[] } catch { return fallback }
}

const fallbackTestimonials = [
    {
        name: 'Mark D.',
        location: 'Glasgow',
        service: 'ECU Repair',
        text: 'Took my BMW 3 Series in with an ECU fault that two other garages couldn\'t fix. Doyen diagnosed it within the hour, repaired and recoded the ECU the same day. Saved me over £900 vs main dealer. Absolutely fantastic — these guys genuinely know their stuff.',
        rating: 5,
    },
    {
        name: 'Tariq H.',
        location: 'Rutherglen',
        service: 'Airbag Reset',
        text: 'Airbag warning light had been on for months after a minor bump. Doyen cleared the crash data, reset the SRS module and sorted a faulty seatbelt pretensioner — all in under 2 hours. Honest pricing, job done properly. Highly recommend.',
        rating: 5,
    },
    {
        name: 'Carolyn P.',
        location: 'Cambuslang',
        service: 'Full Diagnostics',
        text: 'My Audi Q5 had a persistent AdBlue warning and the dealer wanted £1,400. Doyen ran a full diagnostic, replaced the NOx sensor and reset the system for a fraction of the price. Really professional, kept me informed throughout. Won\'t go anywhere else now.',
        rating: 5,
    },
]

const fallbackProcess = [
    { step: '1', title: 'Book Online', desc: 'Simple 3-step booking process. Choose your service, select a time that suits you.', icon: '📅' },
    { step: '2', title: 'We Inspect', desc: 'Our certified technicians perform a thorough inspection using the latest diagnostic equipment.', icon: '🔍' },
    { step: '3', title: 'Get Quote', desc: 'Receive a detailed quote with no hidden charges. We only proceed with your approval.', icon: '💰' },
    { step: '4', title: 'Quality Work', desc: 'Expert repairs using genuine parts with warranty. Your vehicle is our priority.', icon: '✅' },
]

const testimonials = computed(() => parseJsonContent(props.websiteContent?.testimonials?.items, fallbackTestimonials))
const process = computed(() => parseJsonContent(props.websiteContent?.process?.items, fallbackProcess))

// Hero content helpers
const hero = computed(() => props.websiteContent?.hero ?? {})
const heroBadgeText        = computed(() => hero.value.badge_text        || 'Advanced Vehicle Electrical Diagnostics & Repair')
const heroHeadline         = computed(() => hero.value.headline          || 'Precision Vehicle Diagnostics')
const heroHeadlineGradient = computed(() => hero.value.headline_gradient || '& Technical Solutions Centre')
const heroSubline          = computed(() => hero.value.subline           || 'Advanced vehicle diagnostics, ECU repair, airbag SRS reset and electrical fault tracing. 16+ years of automotive experience. Glasgow-based, serving Scotland.')
const heroCtaPrimary       = computed(() => hero.value.cta_primary       || 'Book Your Appointment')
const heroCtaSecondary     = computed(() => hero.value.cta_secondary     || 'Get a Quote')
const heroStat1Value       = computed(() => hero.value.stat_1_value      || '16+')
const heroStat1Label       = computed(() => hero.value.stat_1_label      || 'Years Experience')
const heroStat2Value       = computed(() => hero.value.stat_2_value      || 'AKL')
const heroStat2Label       = computed(() => hero.value.stat_2_label      || 'All-Key-Lost Solution')
const heroStat3Value       = computed(() => hero.value.stat_3_value      || 'ECU')
const heroStat3Label       = computed(() => hero.value.stat_3_label      || 'Specialist')

// Opening hours helpers
const hours = computed(() => props.websiteContent?.hours ?? {})
const hoursTopbar  = computed(() => hours.value.topbar   || 'Mon-Fri: 8:00-17:30 | Sat: 8:00-12:30')
const hoursMonFri  = computed(() => hours.value.mon_fri  || 'Mon–Fri: 9:00 am – 6:00 pm')
const hoursSat     = computed(() => hours.value.saturday || 'Saturday: 10:00 am – 3:00 pm')
const hoursSun     = computed(() => hours.value.sunday   || 'Sunday: Closed')

// SEO helpers
const seo = computed(() => props.websiteContent?.seo ?? {})
const seoTitle       = computed(() => seo.value.meta_title       || 'Doyen Auto Services - Professional Garage & MOT Centre in Glasgow')
const seoDescription = computed(() => seo.value.meta_description || '')

// Social links
const social = computed(() => props.websiteContent?.social ?? {})
const facebookUrl   = computed(() => social.value.facebook_url  || '')
const instagramUrl  = computed(() => social.value.instagram_url || '')
const tiktokUrl     = computed(() => social.value.tiktok_url    || '')

// Services — expandable category cards
const expandedService = ref<string | null>(null)
function toggleService(id: string) {
    expandedService.value = expandedService.value === id ? null : id
}
const serviceCategories = [
    {
        id: 'maintenance',
        icon: '🔩',
        color: 'blue',
        title: 'Maintenance & MOT',
        tagline: 'Full services, interim services, oil changes and MOT testing',
        bookingService: 'full-service',
        highlight: false,
        items: [
            'Full Service',
            'Interim Service',
            'Oil & Oil Filter Change',
            'Full Service + MOT',
            'Interim Service + MOT',
            'Oil/Filter Change + MOT',
            'MOT Only',
        ],
    },
    {
        id: 'general-repairs',
        icon: '🔧',
        color: 'indigo',
        title: 'General Vehicle Repairs',
        tagline: 'Engine, brakes, suspension, clutch, timing belts and more',
        bookingService: 'general-repairs-maintenance',
        highlight: false,
        items: [
            'Engine repairs & servicing',
            'Brake repair & replacement',
            'Suspension & steering repairs',
            'Clutch & gearbox repairs',
            'Timing belt & chain replacement',
        ],
    },
    {
        id: 'ecu-diagnostics',
        icon: '💻',
        color: 'purple',
        title: 'Advanced Diagnostics & ECU Services',
        tagline: 'Dealer-level diagnostics, ECU repair, coding & programming',
        bookingService: 'ecu-testing-fault-code-analysis',
        highlight: false,
        items: [
            'ECU diagnostics & fault finding',
            'ECU testing & replacement',
            'ECU coding & programming',
            'Immobiliser fault diagnosis',
            'Key cutting and programming',
        ],
    },
    {
        id: 'airbag-safety',
        icon: '🛡️',
        color: 'red',
        title: 'Airbag & Safety System Services',
        tagline: 'SRS reset, airbag crash data removal & seatbelt services',
        bookingService: 'airbag-crash-data-reset',
        highlight: true,
        items: [
            'Airbag crash data removal',
            'SRS module reset',
            'Airbag module repair',
            'Seatbelt pretensioner reset',
            'Airbag light diagnostics',
        ],
    },
    {
        id: 'performance',
        icon: '⚡',
        color: 'amber',
        title: 'ECU Remapping & Performance Tuning',
        tagline: 'Stage 1 & 2 remaps, eco tuning, gearbox (TCU) tuning and custom solutions',
        bookingService: 'ecu-remapping',
        highlight: false,
        items: [
            'Stage 1 & Stage 2 Performance Remaps',
            'Eco & Fuel Economy Remaps',
            'Gearbox (TCU) Tuning',
            'Custom Tuning Solutions',
        ],
    },
    {
        id: 'emissions',
        icon: '♻️',
        color: 'green',
        title: 'Emission Services',
        tagline: 'DPF, EGR, AdBlue, Lambda repairs and DTC deletion',
        bookingService: 'dpf-repair-off',
        highlight: false,
        items: [
            'DPF Repairs / Off',
            'EGR Repairs / Off',
            'AdBlue / SCR Repairs or Off',
            'Oxygen (Lambda) Repairs',
            'DTCs Delete',
        ],
    },
    {
        id: 'mileage',
        icon: '🖥️',
        color: 'slate',
        title: 'Mileage Correction Services',
        tagline: 'Instrument cluster replacement, mileage correction & dashboard repairs',
        bookingService: 'mileage-correction',
        highlight: false,
        items: [
            'Instrument Cluster Replacement',
            'Mileage Correction',
            'Dashboard Display Repairs',
        ],
    },
    {
        id: 'electrical',
        icon: '🔌',
        color: 'cyan',
        title: 'Electrical & Electronic Repairs',
        tagline: 'Wiring, CAN network, battery and charging system diagnosis',
        bookingService: 'electrical-fault-tracing',
        highlight: false,
        items: [
            'Wiring fault tracing',
            'CAN network diagnostics',
            'Battery drain diagnosis',
            'Starter & alternator testing',
        ],
    },
    {
        id: 'commercial',
        icon: '🚚',
        color: 'slate',
        title: 'Commercial & Fleet Services',
        tagline: 'Van diagnostics and fleet maintenance support',
        bookingService: 'commercial-fleet',
        highlight: false,
        items: [
            'Van diagnostics',
            'Sprinter, Iveco & Transit specialist work',
            'Fleet maintenance support',
        ],
    },
]

/**
 * If the backend returned website-visible services, build dynamic cards.
 * Otherwise fall back to the hardcoded serviceCategories above.
 */
const displayServiceCategories = computed(() => {
    const ws = props.websiteServices
    if (!ws || Object.keys(ws).length === 0) return serviceCategories

    return Object.entries(ws).map(([category, services]) => {
        // Use first service's icon as the card icon (fallback to 🔧)
        const firstIcon = services[0]?.icon || '🔧'
        const firstId   = services[0]?.category?.toLowerCase().replace(/\s+/g, '-') || String(services[0]?.id)
        return {
            id: firstId + '-' + category.toLowerCase().replace(/\s+/g, '-'),
            icon: firstIcon,
            color: 'indigo',
            title: category,
            tagline: `${services.length} service${services.length !== 1 ? 's' : ''} available`,
            bookingService: 'general-repairs-maintenance',
            highlight: false,
            items: services.map(s => {
                let label = s.name
                if (s.price && s.price > 0) label += ` — from £${Number(s.price).toFixed(2)}`
                return label
            }),
        }
    })
})
</script>

<template>
    <Head :title="seoTitle">
        <meta v-if="seoDescription" name="description" :content="seoDescription" />
    </Head>

    <div class="min-h-screen bg-white">
        <!-- Top Bar -->
        <div class="bg-gradient-to-r from-navy-950 to-navy-900 text-white py-2">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex flex-wrap items-center justify-between text-xs sm:text-sm">
                    <div class="flex items-center gap-4">
                        <a :href="garageTelHref" class="flex items-center gap-2 hover:text-electric-400 transition">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                            </svg>
                            <span class="hidden sm:inline">{{ garagePhone }}</span>
                        </a>
                        <span class="text-gray-400 hidden sm:inline">|</span>
                        <a :href="garageMailHref" class="hidden md:flex items-center gap-2 hover:text-electric-400 transition">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                            </svg>
                            <span>{{ garageEmail }}</span>
                        </a>
                        <span class="text-gray-400 hidden md:inline">|</span>
                        <div class="flex items-center gap-2">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            <span class="hidden md:inline">{{ hoursTopbar }}</span>
                            <span class="md:hidden">Mon-Sat</span>
                        </div>
                    </div>
                    <div class="flex items-center gap-3">
                        <Link :href="route('/customer/login')" class="hover:text-electric-400 transition hidden sm:inline">
                            Customer Portal
                        </Link>
                    </div>
                </div>
            </div>
        </div>

        <!-- Navigation -->
        <nav class="bg-white shadow-sm sticky top-0 z-50">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center h-20">
                    <div class="flex items-center">
                        <div class="flex items-center gap-3">
                            <div class="w-12 h-12 bg-gradient-to-br from-electric-600 to-electric-700 rounded-xl flex items-center justify-center shadow-lg">
                                <span class="text-white font-bold text-xl">D</span>
                            </div>
                            <div>
                                <span class="text-2xl font-bold bg-gradient-to-r from-electric-600 to-electric-700 bg-clip-text text-transparent">{{ garageName }}</span>
                                <div class="text-xs text-gray-500 font-medium">Auto Electrical and Diagnostic Specialist</div>
                            </div>
                        </div>
                    </div>
                    <div class="hidden md:flex items-center gap-8">
                        <a href="#services" class="text-gray-700 hover:text-electric-600 font-medium transition">Services</a>
                        <Link :href="route('/about')" class="text-gray-700 hover:text-electric-600 font-medium transition">About</Link>
                        <a href="#testimonials" class="text-gray-700 hover:text-electric-600 font-medium transition">Reviews</a>
                        <a href="#contact" class="text-gray-700 hover:text-electric-600 font-medium transition">Contact</a>
                        <Link :href="route('/customer/login')" class="inline-flex items-center px-4 py-2 border border-electric-600 text-electric-600 font-medium rounded-lg hover:bg-electric-50 transition text-sm">
                            <svg class="w-4 h-4 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                            My Account
                        </Link>
                        <Link :href="route('/book-online')" class="inline-flex items-center px-6 py-2.5 bg-gradient-to-r from-electric-600 to-electric-700 text-white font-semibold rounded-lg hover:shadow-lg transform hover:-translate-y-0.5 transition-all">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                            Get a Quote
                        </Link>
                    </div>
                    <!-- Mobile: show account + book buttons -->
                    <div class="flex md:hidden items-center gap-2">
                        <Link :href="route('/customer/login')" class="inline-flex items-center px-3 py-2 border border-electric-600 text-electric-600 font-medium rounded-lg hover:bg-electric-50 transition text-xs">
                            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                            My Account
                        </Link>
                        <Link :href="route('/book-online')" class="inline-flex items-center px-3 py-2 bg-electric-600 text-white font-semibold rounded-lg transition text-xs">
                            Book
                        </Link>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Hero Section -->
        <section class="relative overflow-hidden bg-gradient-to-br from-navy-950 via-navy-800 to-navy-950">
            <!-- Animated background pattern -->
            <div class="absolute inset-0 opacity-10">
                <div class="absolute inset-0" style="background-image: radial-gradient(circle at 2px 2px, white 1px, transparent 0); background-size: 40px 40px;"></div>
            </div>
            
            <div class="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                    <div class="text-white">
                        <div class="inline-flex items-center gap-2 bg-electric-600/30 backdrop-blur-sm px-4 py-2 rounded-full mb-6 border border-electric-400/30">
                            <svg class="w-5 h-5 text-green-400" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                            </svg>
                            <span class="text-sm font-semibold">{{ heroBadgeText }}</span>
                        </div>
                        
                        <h1 class="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-6">
                            {{ heroHeadline }}
                            <span class="block bg-gradient-to-r from-electric-400 to-electric-200 bg-clip-text text-transparent">{{ heroHeadlineGradient }}</span>
                        </h1>
                        
                        <p class="text-xl text-electric-200 mb-8 leading-relaxed">{{ heroSubline }}</p>
                        
                        <div class="flex flex-wrap gap-4 mb-10">
                            <Link :href="route('/book-online')" class="inline-flex items-center px-8 py-4 bg-gradient-to-r from-electric-600 to-electric-700 text-white font-bold rounded-xl hover:shadow-2xl transform hover:scale-105 transition-all">
                                <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                                {{ heroCtaPrimary }}
                            </Link>
                            <a :href="garageTelHref" class="inline-flex items-center px-8 py-4 bg-white/10 backdrop-blur-sm text-white font-bold rounded-xl border-2 border-white/30 hover:bg-white/20 transition-all">
                                <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                                </svg>
                                {{ heroCtaSecondary }}
                            </a>
                        </div>
                        
                        <!-- Quick Stats -->
                        <div class="grid grid-cols-3 gap-6">
                            <div class="text-center">
                                <div class="text-3xl font-bold text-white mb-1">{{ heroStat1Value }}</div>
                                <div class="text-xs text-electric-400">{{ heroStat1Label }}</div>
                            </div>
                            <div class="text-center">
                                <div class="text-3xl font-bold text-white mb-1">{{ heroStat2Value }}</div>
                                <div class="text-xs text-electric-400">{{ heroStat2Label }}</div>
                            </div>
                            <div class="text-center">
                                <div class="text-3xl font-bold text-white mb-1">{{ heroStat3Value }}</div>
                                <div class="text-xs text-electric-400">{{ heroStat3Label }}</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Hero Image/Illustration Placeholder -->
                    <div class="hidden lg:block">
                        <div class="relative">
                            <div class="bg-gradient-to-br from-electric-600/20 to-cyan-500/20 backdrop-blur-xl rounded-3xl p-8 border border-white/20">
                                <div class="bg-white/10 rounded-2xl p-8 space-y-4">
                                    <div class="flex items-center gap-4">
                                        <div class="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-xl flex items-center justify-center">
                                            <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17H3a2 2 0 01-2-2V5a2 2 0 012-2h14a2 2 0 012 2v10a2 2 0 01-2 2h-2" />
                                            </svg>
                                        </div>
                                        <div class="text-white">
                                            <div class="font-bold text-lg">Dealer-Level Equipment</div>
                                            <div class="text-sm text-electric-200">Same tools as main dealers</div>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-4">
                                        <div class="w-16 h-16 bg-gradient-to-br from-electric-400 to-electric-600 rounded-xl flex items-center justify-center">
                                            <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                            </svg>
                                        </div>
                                        <div class="text-white">
                                            <div class="font-bold text-lg">Transparent Pricing</div>
                                            <div class="text-sm text-electric-200">No hidden charges, ever</div>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-4">
                                        <div class="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-xl flex items-center justify-center">
                                            <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                                            </svg>
                                        </div>
                                        <div class="text-white">
                                            <div class="font-bold text-lg">Fast Turnaround</div>
                                            <div class="text-sm text-electric-200">Priority service for trade</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Trust Bar with Certifications -->
        <section class="bg-white py-6 border-y border-gray-200">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex flex-wrap justify-center items-center gap-8 lg:gap-12">
                    <div class="flex items-center gap-3">
                        <div class="w-12 h-12 bg-electric-100 rounded-full flex items-center justify-center">
                            <svg class="w-7 h-7 text-electric-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17H3a2 2 0 01-2-2V5a2 2 0 012-2h14a2 2 0 012 2v10a2 2 0 01-2 2h-2" />
                            </svg>
                        </div>
                        <div>
                            <div class="font-bold text-gray-900 text-sm">Dealer-Level Equipment</div>
                            <div class="text-xs text-gray-500">Professional diagnostic tools</div>
                        </div>
                    </div>
                    <div class="flex items-center gap-3">
                        <div class="w-12 h-12 bg-electric-100 rounded-full flex items-center justify-center">
                            <svg class="w-7 h-7 text-electric-600" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                            </svg>
                        </div>
                        <div>
                            <div class="font-bold text-gray-900 text-sm">16+ Years Experience</div>
                            <div class="text-xs text-gray-500">Founded by Ganiyu Ajayi</div>
                        </div>
                    </div>
                    <div class="flex items-center gap-3">
                        <div class="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                            <svg class="w-7 h-7 text-purple-600" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
                            </svg>
                        </div>
                        <div>
                            <div class="font-bold text-gray-900 text-sm">ECU & Airbag Specialist</div>
                            <div class="text-xs text-gray-500">Complex faults, accurate solutions</div>
                        </div>
                    </div>
                    <div class="flex items-center gap-3">
                        <div class="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center">
                            <svg class="w-7 h-7 text-amber-600" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clip-rule="evenodd" />
                            </svg>
                        </div>
                        <div>
                            <div class="font-bold text-gray-900 text-sm">Fast Turnaround</div>
                            <div class="text-xs text-gray-500">Trade &amp; retail customers</div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Our Process -->
        <section class="py-16 lg:py-24 bg-gradient-to-b from-gray-50 to-white">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center mb-16">
                    <div class="inline-block px-4 py-2 bg-electric-100 rounded-full text-electric-700 font-semibold text-sm mb-4">HOW IT WORKS</div>
                    <h2 class="text-4xl font-bold text-gray-900 mb-4">Simple, Transparent Process</h2>
                    <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                        From booking to collection, we make car servicing hassle-free
                    </p>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                    <div v-for="item in process" :key="item.step" class="relative">
                        <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-2 border border-gray-100">
                            <div class="absolute -top-4 -right-4 w-12 h-12 bg-gradient-to-br from-electric-600 to-electric-700 rounded-full flex items-center justify-center text-white font-bold shadow-lg">
                                {{ item.step }}
                            </div>
                            <div class="text-5xl mb-4">{{ item.icon }}</div>
                            <h3 class="text-xl font-bold text-gray-900 mb-3">{{ item.title }}</h3>
                            <p class="text-gray-600 leading-relaxed">{{ item.desc }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!--Services Section -->
        <section id="services" class="py-16 lg:py-24 bg-gray-50">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center mb-14">
                    <div class="inline-block px-4 py-2 bg-electric-100 rounded-full text-electric-700 font-semibold text-sm mb-4">OUR SERVICES</div>
                    <h2 class="text-4xl font-bold text-gray-900 mb-4">Our Services</h2>
                    <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                        Click any service category to see what's included, then get a quote
                    </p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div v-for="cat in displayServiceCategories" :key="cat.id">
                        <!-- Card header — always visible, click to expand -->
                        <div
                            @click="toggleService(cat.id)"
                            :class="[
                                'bg-white rounded-2xl border-2 cursor-pointer transition-all duration-200 select-none',
                                expandedService === cat.id ? 'border-electric-600 shadow-xl' : 'border-gray-200 hover:border-electric-200 hover:shadow-md',
                            ]"
                        >
                            <div class="p-6">
                                <div class="flex items-start justify-between">
                                    <div class="flex items-center gap-4">
                                        <div class="text-4xl">{{ cat.icon }}</div>
                                        <div>
                                            <div class="flex items-center gap-2 flex-wrap">
                                                <h3 class="text-lg font-bold text-gray-900 leading-tight">{{ cat.title }}</h3>
                                                <span v-if="cat.highlight" class="inline-block px-2 py-0.5 bg-red-100 text-red-700 text-xs font-bold rounded-full">Our Speciality</span>
                                            </div>
                                            <p class="text-sm text-gray-500 mt-0.5">{{ cat.tagline }}</p>
                                        </div>
                                    </div>
                                    <svg
                                        :class="['w-5 h-5 text-gray-400 flex-shrink-0 mt-1 transition-transform duration-200', expandedService === cat.id ? 'rotate-180' : '']"
                                        fill="none" stroke="currentColor" viewBox="0 0 24 24"
                                    >
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                                    </svg>
                                </div>
                            </div>

                            <!-- Expanded detail panel -->
                            <div v-if="expandedService === cat.id" class="px-6 pb-6 border-t border-gray-100 pt-4">
                                <ul class="space-y-2 mb-5">
                                    <li v-for="item in cat.items" :key="item" class="flex items-center gap-2 text-sm text-gray-700">
                                        <svg class="w-4 h-4 text-green-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" />
                                        </svg>
                                        {{ item }}
                                    </li>
                                </ul>
                                <Link
                                    :href="route(`/book-online?service=${cat.bookingService}`)"
                                    @click.stop
                                    class="inline-flex items-center px-5 py-2.5 bg-electric-600 hover:bg-electric-700 text-white text-sm font-bold rounded-lg transition"
                                >
                                    Get a Quote
                                    <svg class="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                                    </svg>
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Bottom CTA -->
                <div class="text-center mt-10">
                    <p class="text-gray-500 text-sm mb-4">Not sure which service you need?</p>
                    <Link :href="route('/book-online')" class="inline-flex items-center px-8 py-4 bg-electric-600 hover:bg-electric-700 text-white font-bold rounded-xl transition">
                        Get a Quote — Book Online
                        <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                        </svg>
                    </Link>
                </div>
            </div>
        </section>

        <!-- Reviews / Google CTA -->
        <section id="testimonials" class="py-16 lg:py-24 bg-gradient-to-br from-electric-50 to-gray-50">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center mb-12">
                    <div class="inline-block px-4 py-2 bg-electric-100 rounded-full text-electric-700 font-semibold text-sm mb-4">REVIEWS</div>
                    <h2 class="text-4xl font-bold text-gray-900 mb-4">See What Our Customers Say</h2>
                    <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                        We let our work speak for itself. Read genuine reviews from real customers on Google.
                    </p>
                </div>

                <!-- Review Cards -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
                    <div v-for="(t, idx) in testimonials" :key="idx" class="bg-white rounded-2xl p-7 shadow-md flex flex-col">
                        <!-- Stars -->
                        <div class="flex items-center gap-1 mb-4">
                            <svg v-for="i in 5" :key="i" class="w-5 h-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                            </svg>
                            <span class="ml-2 text-xs font-semibold text-electric-600 bg-electric-50 px-2 py-0.5 rounded-full">{{ t.service }}</span>
                        </div>
                        <p class="text-gray-700 text-sm leading-relaxed italic flex-1">&ldquo;{{ t.text }}&rdquo;</p>
                        <div class="mt-5 flex items-center gap-3">
                            <!-- Google G logo small -->
                            <svg class="w-5 h-5 flex-shrink-0" viewBox="0 0 48 48">
                                <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
                                <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
                                <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
                                <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
                            </svg>
                            <div>
                                <div class="font-bold text-gray-900 text-sm">{{ t.name }}</div>
                                <div class="text-xs text-gray-400">{{ t.location }} &middot; Google Review</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                    <!-- Google Review CTA card -->
                    <a :href="googleReviewLink" target="_blank" rel="noopener noreferrer"
                        class="group flex flex-col items-center text-center bg-white rounded-2xl p-10 shadow-lg hover:shadow-xl transition-all border-2 border-transparent hover:border-electric-200">
                        <!-- Google G logo -->
                        <svg class="w-14 h-14 mb-5" viewBox="0 0 48 48">
                            <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
                            <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
                            <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
                            <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
                        </svg>
                        <h3 class="text-xl font-bold text-gray-900 mb-2">Leave Us a Google Review</h3>
                        <p class="text-gray-500 text-sm mb-6 leading-relaxed">
                            Happy with our service? A quick review on Google helps other customers find us and means a lot to our team.
                        </p>
                        <span class="inline-flex items-center gap-2 px-6 py-3 bg-electric-600 group-hover:bg-electric-700 text-white font-bold rounded-xl transition">
                            Write a Review
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                            </svg>
                        </span>
                    </a>

                    <!-- Phone / quick question card -->
                    <div class="flex flex-col items-center text-center bg-white rounded-2xl p-10 shadow-lg border-2 border-transparent">
                        <div class="w-14 h-14 bg-green-100 rounded-full flex items-center justify-center mb-5">
                            <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.948V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                            </svg>
                        </div>
                        <h3 class="text-xl font-bold text-gray-900 mb-2">Have a Question?</h3>
                        <p class="text-gray-500 text-sm mb-6 leading-relaxed">
                            Not sure which service you need? Our team is happy to help. Give us a call and we'll advise you honestly.
                        </p>
                        <a :href="garageTelHref"
                            class="inline-flex items-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-bold rounded-xl transition">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.948V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                            </svg>
                            {{ garagePhone }}
                        </a>
                    </div>
                </div>
            </div>
        </section>

        <!-- About Section -->
        <section id="about" class="py-16 lg:py-24 bg-white">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

                <!-- Intro -->
                <div class="text-center mb-14">
                    <div class="inline-block px-4 py-2 bg-electric-100 rounded-full text-electric-700 font-semibold text-sm mb-4">ABOUT US</div>
                    <h2 class="text-4xl font-bold text-gray-900 mb-4">Advanced Vehicle Electrical Diagnostics &amp; Repair</h2>
                    <p class="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed">
                        Established in 2023, Doyen Auto Services is a Glasgow-based advanced vehicle electrical diagnostics and repair specialist
                        serving customers across Glasgow and the wider Scotland region. Founded by <strong>Ganiyu Ajayi</strong>, who brings
                        over 16 years of hands-on automotive industry experience.
                    </p>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">

                    <!-- Left: specialisms + why choose -->
                    <div>
                        <h3 class="text-2xl font-bold text-gray-900 mb-5">Glasgow Vehicle Electrical &amp; Diagnostic Specialists</h3>
                        <p class="text-gray-600 mb-6 leading-relaxed">
                            With today's vehicles relying heavily on complex electronic control systems, accurate fault diagnosis is
                            more important than ever. We focus on professional testing, dealer-level diagnostic equipment, and
                            long-term repair solutions — not guesswork.
                        </p>
                        <ul class="space-y-3 mb-8">
                            <li v-for="point in [
                                { text: 'Advanced vehicle diagnostics', icon: '🔍' },
                                { text: 'ECU testing, repair, coding &amp; programming', icon: '💻' },
                                { text: 'Airbag crash data removal (SRS reset)', icon: '🛡️' },
                                { text: 'Immobiliser fault diagnosis', icon: '🔐' },
                                { text: 'Key programming', icon: '🗝️' },
                                { text: 'AdBlue system diagnostics &amp; repair', icon: '♻️' },
                                { text: 'DPF and emission fault diagnosis', icon: '🌿' },
                                { text: 'Electrical fault tracing &amp; CAN network testing', icon: '⚡' },
                            ]" :key="point.text" class="flex items-center gap-3">
                                <div class="flex-shrink-0 w-9 h-9 bg-electric-50 rounded-full flex items-center justify-center text-lg">
                                    {{ point.icon }}
                                </div>
                                <span class="text-gray-700" v-html="point.text"></span>
                            </li>
                        </ul>
                        <Link :href="route('/book-online?service=ecu-testing-fault-code-analysis')" class="inline-flex items-center px-8 py-4 bg-gradient-to-r from-electric-600 to-electric-700 text-white font-bold rounded-xl hover:shadow-lg transform hover:scale-105 transition-all">
                            Book a Diagnostic Today
                            <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                            </svg>
                        </Link>
                    </div>

                    <!-- Right: stat cards + why choose points -->
                    <div class="space-y-6">
                        <div class="grid grid-cols-2 gap-4">
                            <div class="bg-gradient-to-br from-electric-600 to-electric-700 rounded-2xl p-6 text-white shadow-xl">
                                <div class="text-4xl font-bold mb-1">16+</div>
                                <div class="text-electric-200 text-sm">Years Industry Experience</div>
                            </div>
                            <div class="bg-gradient-to-br from-navy-900 to-navy-950 rounded-2xl p-6 text-white shadow-xl">
                                <div class="text-4xl font-bold mb-1">SRS</div>
                                <div class="text-electric-200 text-sm">Airbag &amp; Crash Data Repairs</div>
                            </div>
                            <div class="bg-gradient-to-br from-purple-600 to-purple-700 rounded-2xl p-6 text-white shadow-xl">
                                <div class="text-4xl font-bold mb-1">ECU</div>
                                <div class="text-purple-100 text-sm">Repair &amp; Programming Specialist</div>
                            </div>
                            <div class="bg-gradient-to-br from-amber-600 to-amber-700 rounded-2xl p-6 text-white shadow-xl">
                                <div class="text-4xl font-bold mb-1">UK</div>
                                <div class="text-amber-100 text-sm">Trade Mail-In Service Available</div>
                            </div>
                        </div>

                        <!-- Why Choose box -->
                        <div class="bg-gray-50 rounded-2xl p-6 border border-gray-100">
                            <h4 class="font-bold text-gray-900 mb-4">Why Choose Doyen Auto Services?</h4>
                            <ul class="space-y-2">
                                <li v-for="why in [
                                    '16 years of automotive industry experience',
                                    'Glasgow-based ECU &amp; diagnostic specialist',
                                    'Dealer-level diagnostic equipment',
                                    'Strong focus on vehicle electronics',
                                    'Fast turnaround for trade customers',
                                    'Professional and transparent service',
                                ]" :key="why" class="flex items-center gap-2 text-sm text-gray-700">
                                    <svg class="w-4 h-4 text-green-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                                        <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" />
                                    </svg>
                                    <span v-html="why"></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Trade callout banner -->
                <div class="mt-14 bg-gradient-to-r from-navy-900 to-navy-950 rounded-2xl p-8 text-white">
                    <div class="flex flex-col md:flex-row items-center justify-between gap-6">
                        <div>
                            <h3 class="text-xl font-bold mb-2">Trade ECU &amp; Airbag Services — Glasgow &amp; UK-Wide</h3>
                            <p class="text-electric-200 text-sm max-w-xl">
                                We support independent garages, body shops, and motor traders with ECU testing &amp; cloning,
                                airbag crash data resets (mail-in UK-wide), advanced diagnostic assistance, software programming,
                                and technical guidance for complex electronic faults.
                            </p>
                        </div>
                        <a :href="garageTelHref" class="flex-shrink-0 inline-flex items-center px-7 py-3 bg-electric-600 hover:bg-electric-700 rounded-xl font-bold transition">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                            </svg>
                            Enquire About Trade Services
                        </a>
                    </div>
                </div>

            </div>
        </section>

        <!-- CTA Section -->
        <section class="py-16 bg-gradient-to-r from-electric-600 to-electric-700">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                <h2 class="text-4xl font-bold text-white mb-4">Ready to Book Your Service?</h2>
                <p class="text-xl text-electric-200 mb-8 max-w-2xl mx-auto">
                    Whether you're a vehicle owner or a trade professional — book online or call us direct
                </p>
                <div class="flex flex-wrap justify-center gap-4">
                    <Link :href="route('/book-online?service=ecu-testing-fault-code-analysis')" class="inline-flex items-center px-10 py-5 bg-white text-electric-700 font-bold rounded-xl hover:shadow-2xl transform hover:scale-105 transition-all text-lg">
                        <svg class="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        Book Online in 3 Minutes
                    </Link>
                    <a :href="garageTelHref" class="inline-flex items-center px-10 py-5 bg-electric-700 text-white font-bold rounded-xl border-2 border-white hover:bg-electric-700 transition-all text-lg">
                        <svg class="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                        </svg>
                        Or Call: {{ garagePhone }}
                    </a>
                </div>
            </div>
        </section>

        <!-- Contact Section -->
        <section id="contact" class="py-16 lg:py-24 bg-gray-50">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center mb-16">
                    <div class="inline-block px-4 py-2 bg-electric-100 rounded-full text-electric-700 font-semibold text-sm mb-4">GET IN TOUCH</div>
                    <h2 class="text-4xl font-bold text-gray-900 mb-4">Visit Us Today</h2>
                    <p class="text-lg text-gray-600">
                        Conveniently located in Rutherglen, serving all of Glasgow
                    </p>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                    <div class="bg-white rounded-2xl p-8 shadow-lg text-center hover:shadow-xl transition-all">
                        <div class="w-16 h-16 bg-electric-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <svg class="w-8 h-8 text-electric-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                            </svg>
                        </div>
                        <h3 class="font-bold text-xl text-gray-900 mb-2">Address</h3>
                        <p class="text-gray-600 leading-relaxed">
                            {{ garageAddress }}<br>
                            {{ garageCity }}<br>
                            {{ garagePostcode }}
                        </p>
                        <a :href="'https://maps.google.com/?q=' + encodeURIComponent(garageAddress + ', ' + garageCity + ' ' + garagePostcode)" target="_blank" rel="noopener" class="inline-block mt-3 text-sm text-electric-600 hover:text-electric-700 font-medium transition">
                            Get Directions →
                        </a>
                    </div>
                    
                    <div class="bg-white rounded-2xl p-8 shadow-lg text-center hover:shadow-xl transition-all">
                        <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                            </svg>
                        </div>
                        <h3 class="font-bold text-xl text-gray-900 mb-2">Phone</h3>
                        <p class="text-gray-600 mb-2">Call us for quotes or bookings</p>
                        <a :href="garageTelHref" class="text-electric-600 font-bold text-lg hover:text-electric-700 transition block">
                            {{ garagePhone }}
                        </a>
                    </div>

                    <div class="bg-white rounded-2xl p-8 shadow-lg text-center hover:shadow-xl transition-all">
                        <div class="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <svg class="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                            </svg>
                        </div>
                        <h3 class="font-bold text-xl text-gray-900 mb-2">Email</h3>
                        <p class="text-gray-600 mb-2">Send us a message anytime</p>
                        <a :href="garageMailHref" class="text-electric-600 font-bold hover:text-electric-700 transition break-all">
                            {{ garageEmail }}
                        </a>
                    </div>
                    
                    <div class="bg-white rounded-2xl p-8 shadow-lg text-center hover:shadow-xl transition-all">
                        <div class="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <svg class="w-8 h-8 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                        <h3 class="font-bold text-xl text-gray-900 mb-2">Opening Hours</h3>
                        <p class="text-gray-600 leading-relaxed">
                            <strong v-if="hoursMonFri">{{ hoursMonFri }}</strong><br v-if="hoursMonFri" />
                            <strong v-if="hoursSat">{{ hoursSat }}</strong><br v-if="hoursSat" />
                            <strong v-if="hoursSun">{{ hoursSun }}</strong>
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Footer -->
        <footer class="bg-gradient-to-br from-navy-950 to-navy-900 text-gray-300">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
                    <div class="col-span-1 md:col-span-2">
                        <div class="flex items-center gap-3 mb-4">
                            <div class="w-12 h-12 bg-gradient-to-br from-electric-600 to-electric-700 rounded-xl flex items-center justify-center shadow-lg">
                                <span class="text-white font-bold text-xl">D</span>
                            </div>
                            <div>
                                <span class="text-2xl font-bold text-white">{{ garageName }}</span>
                                <div class="text-xs text-gray-400">Auto Electrical and Diagnostic Specialist</div>
                            </div>
                        </div>
                        <p class="text-gray-400 mb-4 leading-relaxed">
                            Glasgow-based precision vehicle diagnostics and technical solutions centre.
                            Serving vehicle owners and trade professionals across Scotland.
                        </p>
                        <div class="flex gap-3">
                            <a v-if="facebookUrl" :href="facebookUrl" target="_blank" rel="noopener" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-electric-600 transition">
                                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                            </a>
                            <a v-if="instagramUrl" :href="instagramUrl" target="_blank" rel="noopener" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-pink-600 transition">
                                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.306.788.717 1.459 1.384 2.126.667.666 1.336 1.079 2.126 1.384.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558.788-.306 1.459-.718 2.126-1.384.666-.667 1.079-1.335 1.384-2.126.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913-.306-.789-.718-1.459-1.384-2.126C21.319 1.347 20.651.935 19.86.63c-.765-.297-1.636-.499-2.913-.558C15.667.012 15.26 0 12 0zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85s-.015 3.585-.074 4.85c-.061 1.17-.256 1.805-.421 2.227-.224.562-.479.96-.899 1.382-.419.419-.824.679-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421-.569-.224-.96-.479-1.379-.899-.421-.419-.69-.824-.9-1.38-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678c-3.405 0-6.162 2.76-6.162 6.162 0 3.405 2.76 6.162 6.162 6.162 3.405 0 6.162-2.76 6.162-6.162 0-3.405-2.76-6.162-6.162-6.162zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405c0 .795-.646 1.44-1.44 1.44-.795 0-1.44-.646-1.44-1.44 0-.794.646-1.439 1.44-1.439.793-.001 1.44.645 1.44 1.439z"/></svg>
                            </a>
                            <a v-if="tiktokUrl" :href="tiktokUrl" target="_blank" rel="noopener" class="w-10 h-10 bg-navy-900 rounded-full flex items-center justify-center hover:bg-electric-600 transition">
                                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.27 6.27 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.69a8.18 8.18 0 004.78 1.52V6.75a4.85 4.85 0 01-1.01-.06z"/></svg>
                            </a>
                        </div>
                    </div>
                    
                    <div>
                        <h4 class="font-bold text-white mb-4 text-lg">Quick Links</h4>
                        <ul class="space-y-2">
                            <li><a href="#services" class="hover:text-electric-400 transition">Our Services</a></li>
                            <li><Link :href="route('/about')" class="hover:text-electric-400 transition">About Us</Link></li>
                            <li><a href="#testimonials" class="hover:text-electric-400 transition">Reviews</a></li>
                            <li><Link :href="route('/book-online?service=key-cutting-programming')" class="hover:text-electric-400 transition">Book Online</Link></li>
                        </ul>
                    </div>
                    
                    <div>
                        <h4 class="font-bold text-white mb-4 text-lg">Services</h4>
                        <ul class="space-y-2">
                            <li><a href="#services" class="hover:text-electric-400 transition">MOT Testing</a></li>
                            <li><a href="#services" class="hover:text-electric-400 transition">Car Servicing</a></li>
                            <li><a href="#services" class="hover:text-electric-400 transition">Diagnostics</a></li>
                            <li><a href="#services" class="hover:text-electric-400 transition">Repairs</a></li>
                        </ul>
                    </div>
                </div>
                
                <div class="border-t border-gray-700 pt-8 text-center">
                    <p class="text-sm text-gray-400">
                        &copy; {{ new Date().getFullYear() }} {{ garageName }}. All rights reserved.
                    </p>
                    <p class="text-xs text-gray-500 mt-2">
                        {{ garageAddress }}, {{ garageCity }}, {{ garagePostcode }} | {{ garagePhone }} | Advanced Vehicle Electrical Diagnostics &amp; Repair
                    </p>
                </div>
            </div>
        </footer>

        <!-- WhatsApp Floating Support Button -->
        <a :href="whatsappSupportHref" target="_blank" rel="noopener"
           title="Chat with us on WhatsApp"
           class="fixed bottom-6 right-6 z-50 flex items-center gap-2 bg-[#25d366] hover:bg-[#1eba57] text-white font-semibold px-4 py-3 rounded-full shadow-2xl transition-all duration-300 hover:scale-105 group">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 flex-shrink-0" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
            </svg>
            <span class="text-sm">Chat with us</span>
        </a>
    </div>
</template>
